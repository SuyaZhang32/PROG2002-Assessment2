module.exports = {
  host: 'localhost',
  user: 'root',
  password: '000513',
  database: 'charityevents_db'
};


